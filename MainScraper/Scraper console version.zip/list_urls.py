from bs4 import BeautifulSoup
import requests
import requests.exceptions
from urllib.parse import urlsplit
from collections import deque


def map_urls(url):
    # a queue of urls to be crawled next
    new_urls = deque([url])
    # a set of urls that we have already processed 
    processed_urls = set()

    while len(new_urls):    
        # move url from the queue to processed url set    
        url = new_urls.popleft()    
        processed_urls.add(url)    

        try:    
            response = requests.get(url)
        except(requests.exceptions.MissingSchema,
               requests.exceptions.ConnectionError, 
               requests.exceptions.InvalidURL, 
               requests.exceptions.InvalidSchema, 
               requests.exceptions.TooManyRedirects, 
               Exception):    
            # add broken urls to it’s own set, then continue       
            continue
        # extract base url to resolve relative links
        parts = urlsplit(url)
        base = parts.netloc
        strip_base = base.replace("www.", "")
        base_url = f"{parts.scheme}://{parts.netloc}"
        path = url[:url.rfind('/')+1] if '/' in parts.path else url

        # initialize beautifulSoup to extract links from html document
        soup = BeautifulSoup(response.content, 'html.parser')
        for link in soup.find_all('a'):
            # extract link url from the anchor    
            anchor = link.attrs["href"] if 'href' in link.attrs else ''
            # stopping duplication
            anchor = anchor.replace('#', '')
            if anchor.startswith('/'):
                local_link = base_url + anchor 
                local_link = local_link
                if not local_link in new_urls and not local_link in processed_urls:
                    new_urls.append(local_link)
            elif strip_base in anchor: 
                if not anchor in new_urls and not anchor in processed_urls:
                    new_urls.append(anchor)
            elif not anchor.startswith('http'):  
                local_link = path + anchor 
                if not local_link in new_urls and not local_link in processed_urls:
                    new_urls.append(local_link)

        yield url


if __name__ == '__main__':
    websites_list = ['https://www.colgate.com/en-us', '', '']

    for website in websites_list:
        for web_page in map_urls(website):
            print(web_page)


