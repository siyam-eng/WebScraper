from bs4 import BeautifulSoup
import requests
import requests.exceptions
import re

def find_code(soup, code):
    """Finds all codes matching with the given code"""
    codes = soup.findAll(text=re.compile(f'{code}'))
    return codes

def get_codes(url, soup, code_list):
    for code in code_list:
        # codes containing present code on page
        present_code = find_code(soup, code)
        for code in present_code:
            code_type = '/' if '/' in code else '-'
            yield {'url': url, 'code': code, 'type': code_type, 'length': len(code)}



def output_codes(url):
    response = requests.get(url)
    soup = BeautifulSoup(response.text,"html.parser")

    code_list = ['CHPAN', 'CHPRO', 'SENO', 'PAN', 'PRO', 'CHSENO']
    for code in get_codes(url, soup, code_list):
        print(code)

urls_list = ["https://www.sensodyne.co.uk/accessibility.html", 'https://www.sensodyne.co.uk/contact.html']

for url in urls_list:
    output_codes(url)




