from list_urls import map_urls
import re
from bs4 import BeautifulSoup
import requests


def find_gtm(soup):
    """"Gets the GTM from a web page"""
    if soup and soup.find('head'):
        gtm_container = soup.head.findAll(text=re.compile(r'GTM'))
        if gtm_container:
            gtm_code = re.search("GTM-[A-Z0-9]{6,7}", str(gtm_container))[0]

            return gtm_code

def find_statement(soup, statement):
    """"Checks for the presence for the given statement"""
    statement_list = soup.findAll(text=re.compile(f'{statement}'))
    return bool(statement_list)


def find_link(soup, link):
    """"Checks for the presence for the given link"""
    a_tags = soup.findAll('a')
    for a in a_tags:
        href = a.attrs['href']  if 'href' in a.attrs else ''
        if link in href:
            return True
        else:
            return False

def find_html_lang(soup):
    """"Gets the language of a webpage if mentioned in html tag"""
    html = soup.find('html')
    if html and 'lang' in html.attrs:
        return html.attrs['lang']

def get_data(url, statement1, statement2, link1, link2, link3):
    """Gets the gtm and lang from a page and check for presence of links and statements mentioned."""

    for i in map_urls(url):
        response = requests.get(i)
        soup = BeautifulSoup(response.text,"html.parser")

        gtm = find_gtm(soup)
        statement_1 = find_statement(soup, statement1)
        statement_2 = find_statement(soup, statement2)
        link_1 = find_link(soup, link1)
        link_2 = find_link(soup, link2)
        link_3 = find_link(soup, link3)
        lang = find_html_lang(soup)

        data_dict = {'url': i, 'GTM': gtm,
        'statement_1': statement_1, 
        'statement_2': statement_2, 
        'link_1': link_1,
        'link_2': link_2,
        'link_3': link_3,
        'lang': lang}
        

        print(data_dict)


if __name__ == '__main__':
    website_inputs = [{'url': 'https://www.colgate.com/en-us',
    'statement1': 'You are viewing the US English site',
    'statement2': 'All Rights Reserved',
    'link1': 'https://www.colgatepalmolive.com/en-us/legal-privacy-policy/terms-of-use',
    'link2': 'https://www.colgatepalmolive.com/en-us/legal-privacy-policy', 
    'link3': 'https://www.colgatepalmolive.com/en-us/legal-privacy-policy/childrens-privacy-statement',
    },
    {'url': 'https://www.sensodyne.co.uk',
    'statement1': 'The content of this site is intended for UK audiences only',
    'statement2': 'All Rights may be reserved.',
    'link1': 'https://terms.gsk.com/en-gb/consumer-healthcare/default/',
    'link2': 'https://privacy.gsk.com/en-gb/consumer-healthcare/', 
    'link3': 'https://privacy.gsk.com/en-gb/consumer-healthcare/',
    },
    ]

    for website in website_inputs:
        get_data(website['url'], 
        website['statement1'], 
        website['statement2'], 
        website['link1'], 
        website['link2'], 
        website['link3'])